#include <stdio.h>
#include <stdlib.h>

void main() {

	system("sudo /etc/init.d/vsftpd start");

	system("sudo adduser ftpuser");

	system("sudo chmod 777 /home/ftpuser");
}
