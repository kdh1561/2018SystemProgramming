#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

void moveFile(char *filename, char *afterDir, char *currentDir);
void copyFile(char *filename, char *afterDir, char *currentDir);
void deleteFile(char *filename);
void compressionFile(char *filename, char *compression);
void ftpfiletransfer(char *filename);

int main() {

	system("clear");

	char filename[100] = "";
	char afterDir[100] = ""; // 이동 후 디렉토리
	char currentDir[100] = ""; // 현재 디렉토리
	char compression[15] = ""; // 압축방식

	int inputCommand; // 커맨드 입력받을 변수
	int inputCompressionCommend; // 압축 방식 입력받을 변수

	getcwd(currentDir, 100); // 현재 작업중인 디렉토리 위치
	printf("1.movefile\n2.copyfile\n3.deletefile\n4.compression\n5.FTP File Transfer\n>> ");
	scanf("%d", &inputCommand);

	switch(inputCommand) {

		case 1:
			strcat(	filename, "test.txt"); //menus[i]
			printf("after directory : "); // 이동 후의 디렉토리 이름 지정
			scanf("%s", afterDir);
			//strcat(afterDir, "/home/kdh/ftpuser");
			moveFile(filename, afterDir, currentDir);
			break;						
		case 2:
			strcat(filename, "test.txt"); //menus[i]
			printf("after directory : ");
			scanf("%s", afterDir);
			//strcat(afterDir, "/home/kdh/ftpuser");
			copyFile(filename, afterDir, currentDir);
			break;
		case 3:
			strcat(filename, "test.txt"); //menus[i]
			deleteFile(filename);
			break;
		case 4:
			printf("1.SingleFile    2.AllFile\n>> ");
			scanf("%d", &inputCompressionCommend);
			switch(inputCompressionCommend){
				case 1:// 현재 선택한 파일만 압축
					strcat(filename, "test.txt"); //menus[i]
					break;
				case 2:// 디렉토리 내 전체 파일을 압축
					strcat(filename, "./*");
					break;
				default:
					printf("fail commned\n");
			}
			strcat(compression, "zip -r ");
			
			compressionFile(filename, compression);
			break;
		case 5:
			strcat(filename, "test.txt");
			ftpfiletransfer(filename);	
			break;
		default:
			printf("fail commned\n");
	}


	return 0;
}


// 파일 이동 함수
void moveFile(char *filename, char *afterDir, char *currentDir) {

	char buf[100] = "";
	char space[3] = " ";
	strcat(buf, "mv ");
	strcat(buf, filename);
	strcat(buf, space);
	strcat(buf, afterDir);
	strcat(buf, "/");
	strcat(buf, filename);

	system(buf);

	printf("%s >> %s \n%s : 파일을 이동시켰습니다.\n", currentDir, afterDir, filename);

}

// 파일 복사 함수
void copyFile(char *filename, char *afterDir, char *currentDir) {

	char buf[100] = "";
	char space[3] = " ";
	strcat(buf, "cp ");
	strcat(buf, filename);
	strcat(buf, space);
	strcat(buf, afterDir);
	strcat(buf, "/");
	strcat(buf, filename);

	system(buf);

	printf("%s >> %s\n%s : 파일을 복사했습니다.\n", currentDir, afterDir, filename);

}

// 파일 삭제 함수
void deleteFile(char *filename) {

	char buf[100] = "";
	strcat(buf, "rm -r ");
	strcat(buf, filename);

	system(buf);

	printf("%s : 파일을 삭제했습니다.\n", filename);

}

//파일 압축 함수
void compressionFile(char *filename, char *compression) {

	char buf[100] = "";
	char space[3] = " ";
	char comp[15] = "";
	char fn[100] = "";

	strcat(comp, ".zip");

	// 압축 파일의 이름 지정
	printf("Compression FileName : ");
	scanf("%s", fn);

	strcat(buf, compression);
	strcat(buf, fn);
	strcat(buf, comp);
	strcat(buf, space);
	strcat(buf, filename);

	system(buf);
	sleep(1); // 동작한다는 느낌이 나도록...

	printf(">> %s%s : 파일을 압축했습니다.\n", fn, comp);

}




//파일 압축 함수
void ftpfiletransfer(char *filename) {

	char buf[100] = "";
	char space[3] = " ";
	char comp[15] = ".zip";
	char fn[100] = "ftpfile";
	char compression[10] = "zip ";
	char enter5[20] = "\n\n\n\n\n";

	int isUser = access( "/home/ftpuser/", 0 );

	// ftp서버를 열어주는 부분.
	// sudo /etc/init.d/vsftpd start와
	// sudo adduser ftpuser 부분 직접 세팅해줘야합니다.
	// 123
	// 123
	/*
	system("sudo /etc/init.d/vsftpd start");
	*/
	//만약 해당 유저가 없으면 유저를 생성해줌.
	//이건 GUI로 구현했을 대 문제의 소지가 많기에
	//기존에 미리 생성해두는 것이 좋아보입니다.	
	/*
	if( isUser == -1 ) {
		system("sudo adduser ftpuser");
		system("sudo chmod 757 /home/ftpuser");
	}*/
	
	//이미 압축파일이면 파일 이름을 변경해서 보내고
	if(strstr(filename, "zip")) {
		strcat(buf, "cp ");
		strcat(buf, filename);
		strcat(buf, " /home/ftpuser/ftpuser.zip");
		system(buf);
	}
	else { // 압축파일이 아니면 압축해서 보냄
		strcat(buf, compression);
		strcat(buf, fn);
		strcat(buf, comp);
		strcat(buf, space);
		strcat(buf, filename);
		system(buf);
		system("mv ftpfile.zip /home/ftpuser/");
	}

	//어차피 서버를 열어줄 때 sudo를 사용했음.
	system("sudo chmod 777 /home/ftpuser/ftpfile.zip");

}
