#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

void moveFile(char *filename, char *afterDir, char *currentDir);
void copyFile(char *filename, char *afterDir, char *currentDir);
void deleteFile(char *filename);
void compressionFile(char *filename, char *compression);

int main() {

	system("clear");

	char filename[100] = "";
	char afterDir[100] = ""; // 이동 후 디렉토리
	char currentDir[100] = ""; // 현재 디렉토리
	char compression[15] = ""; // 압축방식

	int inputCommand; // 커맨드 입력받을 변수
	int inputCompressionCommend; // 압축 방식 입력받을 변수

	getcwd(currentDir, 100); // 현재 작업중인 디렉토리 위치
	printf("1.movefile\n2.copyfile\n3.deletefile\n4.compression\n>> ");
	scanf("%d", &inputCommand);

	switch(inputCommand) {

		case 1:
			strcat(	filename, "test.txt"); //menus[i]
			printf("after directory : "); // 이동 후의 디렉토리 이름 지정
			scanf("%s", afterDir);
			//strcat(afterDir, "/home/kdh/ftpuser");
			moveFile(filename, afterDir, currentDir);
			break;						
		case 2:
			strcat(filename, "test.txt"); //menus[i]
			printf("after directory : ");
			scanf("%s", afterDir);
			//strcat(afterDir, "/home/kdh/ftpuser");
			copyFile(filename, afterDir, currentDir);
			break;
		case 3:
			strcat(filename, "test.txt"); //menus[i]
			deleteFile(filename);
			break;
		case 4:
			printf("1.SingleFile    2.AllFile\n>> ");
			scanf("%d", &inputCompressionCommend);
			switch(inputCompressionCommend){
				case 1:// 현재 선택한 파일만 압축
					strcat(filename, "test.txt"); //menus[i]
					break;
				case 2:// 디렉토리 내 전체 파일을 압축
					strcat(filename, "./*");
					break;
				default:
					printf("fail commned\n");
			}
			strcat(compression, "zip -r ");
			
			compressionFile(filename, compression);
			break;
		default:
			printf("fail commned\n");
	}


	return 0;
}


// 파일 이동 함수
void moveFile(char *filename, char *afterDir, char *currentDir) {

	char buf[100] = "";
	char space[3] = " ";
	strcat(buf, "mv ");
	strcat(buf, filename);
	strcat(buf, space);
	strcat(buf, afterDir);
	strcat(buf, "/");
	strcat(buf, filename);

	system(buf);

	printf("%s >> %s \n%s : 파일을 이동시켰습니다.\n", currentDir, afterDir, filename);

}

// 파일 복사 함수
void copyFile(char *filename, char *afterDir, char *currentDir) {

	char buf[100] = "";
	char space[3] = " ";
	strcat(buf, "cp ");
	strcat(buf, filename);
	strcat(buf, space);
	strcat(buf, afterDir);
	strcat(buf, "/");
	strcat(buf, filename);

	system(buf);

	printf("%s >> %s\n%s : 파일을 복사했습니다.\n", currentDir, afterDir, filename);

}

// 파일 삭제 함수
void deleteFile(char *filename) {

	char buf[100] = "";
	strcat(buf, "rm -r ");
	strcat(buf, filename);

	system(buf);

	printf("%s : 파일을 삭제했습니다.\n", filename);

}

//파일 압축 함수
void compressionFile(char *filename, char *compression) {

	char buf[100] = "";
	char space[3] = " ";
	char comp[15] = "";
	char fn[100] = "";

	strcat(comp, ".zip");

	// 압축 파일의 이름 지정
	printf("Compression FileName : ");
	scanf("%s", fn);

	strcat(buf, compression);
	strcat(buf, fn);
	strcat(buf, comp);
	strcat(buf, space);
	strcat(buf, filename);

	system(buf);
	sleep(1); // 동작한다는 느낌이 나도록...

	printf(">> %s%s : 파일을 압축했습니다.\n", fn, comp);

}
